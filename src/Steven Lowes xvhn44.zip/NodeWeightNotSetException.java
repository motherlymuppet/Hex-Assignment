/**
 * Created by Steven on 18/04/2016.
 */
public class NodeWeightNotSetException extends Exception{
}
